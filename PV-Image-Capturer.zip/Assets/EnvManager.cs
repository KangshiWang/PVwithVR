using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using TMPro;

public class EnvManager : MonoBehaviour
{

    public GameObject mainCameraObj;
    public GameObject dirLightObj;

    public TextMeshProUGUI textTime;

    public double Longitude;
    public double Latitude;
    public int year;
    public int month;
    public int day;
    public int hour;
    public int minute;
    public double timeZone;


    double height;
    double direction;


    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

        if (hour < 19 || (hour == 19 && minute == 0))
        {
            UpdateSun();

            string timeString = year + "-" + month + "-" + day + " " + hour + ":" + minute.ToString().PadLeft(2, '0');
            textTime.text = timeString + "\n" + Latitude + " N, " + Longitude + "E";

            timeString = timeString.Replace(':', '-');

            Debug.Log(timeString);

            // StartCoroutine(TakeScreenShot("screenshots\\" + timeString + ".png"));

            minute += 1;

            if (minute >= 60)
            {
                minute = 0;
                hour += 1;
            }
        }

    }


    IEnumerator TakeScreenShot(string filename)
    {
        yield return new WaitForEndOfFrame();
        ScreenCapture.CaptureScreenshot(filename);
    }

    void UpdateSun()
    {

        SunPositionNR(Longitude, Latitude, year, month, day, hour, minute, 0, timeZone, out height, out direction);

        dirLightObj.transform.rotation = Quaternion.Euler((float)height, (float)direction, 0);

    }


    /*
    ���������                           
    Longitude - ���ȣ���λ"��"��
    Latitude  - γ�ȣ���λ"��"��
    Year      - ��
    Month     - ��
    Day       - ��
    Hour      - ʱ
    Minute    - ��
    Second    - ��
 
    ���������
    Height    - ̫���߶Ƚ�   ����λ"��"��
    Direction - ̫����λ��   ����λ"��"��
    */

    void SunPositionNR(double Longitude, double Latitude, int year, int month, int day, int hour, int minute, int second, double timeZone, out double height, out double direction)
    {
        double A = year / 4;
        double B = A - Math.Floor(A);
        double C = 32.8;
        if (month <= 2)
            C = 30.6;
        if (B == 0 && month > 2)
            C = 31.8;
        double G = Math.Floor(30.6 * month - C + 0.5) + day;
        double L = Longitude / 15.0;                            //��������   
        double H = hour - timeZone + minute / 60.0 + second / 3600.0;  //ʱ������   
        double N = G + (H - L) / 24.0;                          //�������
        double theta, NO;     //thetaΪ�ս�
        NO = 79.6764 + 0.2422 * (year - 1985) - Math.Floor((year - 1985) / 4.0);
        theta = 2 * Math.PI * (N - NO) / 365.2422;

        double lat;//��γ��
        lat = 0.3723 + 23.2567 * Math.Sin(theta) + 0.1149 * Math.Sin(2 * theta) - 0.1712 * Math.Sin(3 * theta) - 0.758 * Math.Cos(theta) + 0.3656 * Math.Cos(2 * theta) + 0.0201 * Math.Cos(3 * theta);
        lat = lat * Math.PI / 180.0;

        double Et;//ʱ��Է���Ϊ��λ��
        Et = 0.0028 - 1.9857 * Math.Sin(theta) + 9.9059 * Math.Sin(2 * theta) - 7.0924 * Math.Cos(theta) - 0.6882 * Math.Cos(2 * theta);

        double timeAngle;//ʱ��
        timeAngle = ((hour - 12) + (minute - (timeZone * 15 - Longitude) * 4.0 + Et) / 60.0) * 15.0;
        timeAngle = timeAngle * Math.PI / 180.0;

        // ��γ���ɽǶ�ת��Ϊ����
        Latitude = Latitude * Math.PI / 180.0;

        // ̫���߶Ƚ�
        height = Math.Sin(Latitude) * Math.Sin(lat) + Math.Cos(Latitude) * Math.Cos(lat) * Math.Cos(timeAngle);
        height = Math.Asin(height);

        // ̫����λ��
        direction = (Math.Sin(height) * Math.Sin(Latitude) - Math.Sin(lat)) / (Math.Cos(height) * Math.Cos(Latitude));
        direction = Math.Acos(direction);

        height = height / Math.PI * 180;
        direction = direction / Math.PI * 180;

        if (timeAngle < 0)  //(�����Ϸ���Ϊ0�ȣ�˳ʱ��Ϊ��)
            direction *= -1.0;
    }

}
